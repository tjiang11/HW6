To solve this problem, we considered a minimum spanning tree, and thus we decided to use Prim's Algorithm
to find the minimum spanning tree of the inputed graph. 

An adjacency list was implemented to represented the graph. The adjacency list was implemented
using an array of array lists where each index of the array represents the name of a vertex
and the array list corresponding to that vertex represents all the neighbors.

This implementation was used due to its efficient ability to get specific elements in O(1) time. 